sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{onPress:function(e){e.getSource().getParent().close()}}});
//# sourceMappingURL=SuggestionFrag.js.map